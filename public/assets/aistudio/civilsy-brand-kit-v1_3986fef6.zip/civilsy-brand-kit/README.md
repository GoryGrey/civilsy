# CIVILSY — Brand Kit v1.0 (Concept Candidate)

**Brand:** CIVILSY  
**Pronunciation:** *SIV-il-see*  
**Primary line:** Your community. Your move.  
**Origin:** Ashtabula, Ohio  
**Position:** A major American consumer-technology brand that makes participation in local democracy ridiculously easy.

This package develops the user's selected **Lake Erie DNA / Concept 01**. The original approved-direction AI concept image is in `reference/`. The included editable SVG is a **clean provisional reconstruction**, not a pixel-perfect vector trace or a legally cleared final logo. Do not claim the vector is identical to the raster reference.

## Brand promise

Civilsy makes it effortless to **understand what is happening, find who is responsible, speak up, and see what happens next**. It is a civic participation product, not a government agency, partisan campaign, political news outlet, or merely an issue-reporting form.

## Logo inventory

| Asset | Usage |
| --- | --- |
| `logos/civilsy-primary.svg` | Primary horizontal lockup, light surfaces |
| `logos/civilsy-reversed.svg` | White wordmark and blue accent, dark surfaces |
| `logos/civilsy-symbol.svg` | Standalone mark |
| `logos/civilsy-monochrome.svg` | Single-color applications |
| `icons/civilsy-app-icon.svg` | Rounded-square app icon master |
| `icons/*.png` | App icon sizes, favicon and social avatar |
| `reference/selected-refined-concept.png` | Source of visual direction; retain for future handoffs |

## Color system

| Token | HEX | Purpose |
| --- | --- | --- |
| `--civilsy-navy` | `#071B42` | Core logo, text, headers, trust |
| `--civilsy-blue` | `#116BFF` | Active accent, actions, Lake Erie motif |
| `--civilsy-paper` | `#F8F7F4` | Warm flagship background |
| `--civilsy-white` | `#FFFFFF` | Cards and UI surfaces |
| `--civilsy-text` | `#14233B` | Standard body text |
| `--civilsy-muted` | `#607087` | Supporting text |
| `--civilsy-border` | `#DDE3ED` | Dividers and inputs |
| `--civilsy-success` | `#157347` | Verified progress (functional only) |
| `--civilsy-warning` | `#A56300` | Needs review (functional only) |
| `--civilsy-danger` | `#B42332` | Errors (functional only) |

**Contrast:** Navy on white/paper is the default. White on blue is suitable for large action controls but run contrast checks for smaller text; use navy where needed. Semantic colors are **UI status colors**, not identity colors. Do not rely solely on color to convey status.

## Typography

- **Recommended free UI face:** Inter (open-source; self-host or load appropriately).
- **Fallback:** system-ui, Segoe UI, Arial, sans-serif.
- **Logo:** The provided SVG uses an approximate bold geometric wordmark. Before formal launch, produce a custom outlined wordmark and clear font licensing.
- Headlines: 700–800 weight, compact tracking where legible.
- Body: 400–500 weight; 16px minimum preferred.
- Buttons/navigation: 600–700 weight.

## Icon meaning

The abstract C and its blue lower sweep carry three ideas: **Civilsy**, **a subtle Lake Erie/Ashtabula origin**, and **forward participation**. It is not a nautical logo and should never be paired with tourist-wave imagery. Use the mark consistently, not multiple alternate C shapes.

## Clearspace and minimum sizes

- Minimum clearspace around any logo: the height of the C's inner negative space divided by two.
- Digital horizontal lockup: minimum 160px wide.
- Standalone icon: test at 16, 24, 32, 48, and 128px; simplify the wave if it visually merges at 16px.
- Do not stretch, skew, rotate, outline, recolor the wave arbitrarily, add shadows/glows, or place over busy imagery.
- For photo backdrops, first add a solid high-contrast band or card.

## Voice and writing

**Useful, direct, neighborly, nonpartisan, confident.** Explain municipal terminology in plain English, give source links and dates, distinguish verified facts from reports or allegations, and suggest an actionable next step.

Preferred: “This street is maintained by the county. Here is the department, the contact information, and the original source.”  
Avoid: “Your corrupt city leaders don't care about your road.”

User actions require consent. Never imply an email was sent until proof exists. Do not invent road jurisdictions, official contact details, meeting dates, government responses, or public records.

## Brand language

- **Corporate tagline:** “Your community. Your move.”
- **Campaign CTA:** “Get Civilsy.”
- **Informal brand verb (aspirational, not a factual market claim):** “Civilsy it.”
- **Product value statement:** “Know what's happening. Find who's responsible. Make your voice heard.”
- **Origin line:** “Born in Ashtabula, Ohio. Built for everywhere.” Use sparingly on About or founder-story materials.
- **Not an official government service:** Clearly label independent civic-platform status in appropriate page footers and about sections.

## Product experience guidelines

The primary UI starts with a prominent natural-language search bar: “My road has a bad pothole.” Results show (1) verified summary, (2) location/jurisdiction uncertainty, (3) responsible offices and contacts, (4) related reports, (5) prepare correspondence/CC, (6) evidence and public tracking. Keep source links, dates, correction and appeal paths visible. The home feed provides comprehensible local updates surfaced by AI but editorially/evidentially checked.

**Brand isn't product functionality:** UI prototypes must never present fabricated city figures or events as live data.

## Social templates and photography

- Use people, roads, local institutions and community life in authentic documentary style; avoid generic capitol photos and flag-draped stock imagery.
- Social avatar: the C mark only, centered within a navy rounded square.
- Hero: short headline, 1 clear CTA, truthful photo, visible source link where factual claims are made.
- Informational cards: issue category, date/location, plain-English impact, verified status, and link to source.
- Use the origin story in national marketing as a genuine founder narrative, not as Ohio-only product positioning.

## Launch & permissions checklist

1. Complete US trademark and confusing-similarity review, including CIVSY and CIVILSY, before final commitment.
2. Independently verify domain and social handle status; available domain does not grant trademark rights.
3. Have a designer check distinctiveness against existing C/wave logos.
4. Manually refine the vector geometry and wordmark, preserving the selected direction.
5. Run small-size/icon and contrast QA across desktop, Android PWA, Play wrapper, and iPhone.
6. Export platform-specific icons/splash assets using actual platform specifications at implementation time.

## Developer handoff

Use `tokens/civilsy.css` and `tokens/civilsy.json`. Treat these assets as canonical **candidate** tokens. Keep all logo uses connected to a single component. Build responsive web/PWA first; do not change the approved product scope or invent live integrations. Keep imagery/assets local and optimizable. The KAMRUI-assisted AI ingestion architecture and low-cost hosting plan are separate from this visual kit.

## Package status

**Design direction selected, final trademark and vector production pending.** Brand kit v1.0 is implementation-ready for prototypes, not a representation of final legal clearance or a registered trademark.
